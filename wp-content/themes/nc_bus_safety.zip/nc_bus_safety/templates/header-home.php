<header class="primary_banner">
  <?php get_template_part('templates/header', 'title'); ?>
  <section class="header_nav">

  </section>
</header>
